import DeleteUser from "@/app/components/DeleteUser";

const DeletePage = () => {
  return (
    <main>
      <DeleteUser />
    </main>
  );
};

export default DeletePage;